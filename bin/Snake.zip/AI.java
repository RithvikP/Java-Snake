import java.util.List;

public interface AI {
	void changeDirection();
	void print();
	
	
}
